const { initializeApp } = require("firebase/app");
const {
  getFirestore,
  collection,
  doc,
  setDoc,
  updateDoc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
} = require("firebase/firestore");

const firebaseConfig = {
  apiKey: "AIzaSyBlNYiHyqfC0mmeKtcoHbP1jw-7UxviNn4",
  authDomain: "stupidmirroros.firebaseapp.com",
  projectId: "stupidmirroros",
  storageBucket: "stupidmirroros.appspot.com",
  messagingSenderId: "130204464466",
  appId: "1:130204464466:web:5709994752937a277e368b",
  measurementId: "G-KJXCEJ1RG7",
};

const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp);

const collectionSettings = collection(db, "settings");

// Sprache
const documentLanguage = doc(collectionSettings, "language");
let language;
onSnapshot(documentLanguage, (doc) => {
  if (doc.exists()) {
    language = doc.data().language;
    timeUpdate(language);
    mottoUpdate(language);
    eventLanguage(language);
    reminderUpdate(language);
    newsUpdate();
    const date = new Date()
    weatherUpdate(date);
  } else {
    language = defaultLanguage;
  }
});

const documentAlignment = doc(collectionSettings, "alignment");
onSnapshot(documentAlignment, (doc) => {
  if (doc.exists()) {
    var stylesheet = document.getElementById('stylesheet');

    if (doc.data().alignment === "horizontal") {
      stylesheet.setAttribute('href', 'style-hori.css');
  } else {
      stylesheet.setAttribute('href', 'style-verti.css');
  }
  }
});

// Time Module
const documentTime = doc(collectionSettings, "time");
onSnapshot(documentTime, (doc) => {
  if (doc.exists()) {
    if (doc.data().boolean === true) {
      dateText.style.visibility = "visible";
      timeText.style.visibility = "visible";
      secText.style.visibility = "visible";
    } else {
      dateText.style.visibility = "hidden";
      timeText.style.visibility = "hidden";
      secText.style.visibility = "hidden";
    }
  } else {
    dateText.style.visibility = "hidden";
    timeText.style.visibility = "hidden";
    secText.style.visibility = "hidden";
  }
});
// News Module
const newsDiv = document.querySelector(".module-news");
const documentNews = doc(collectionSettings, "news");
onSnapshot(documentNews, (doc) => {
  if (doc.exists()) {
    if (doc.data().boolean === true) {
      newsDiv.style.visibility = "visible";
    } else {
      newsDiv.style.visibility = "hidden";
    }
    newsUpdate();
  } else {
    newsDiv.style.visibility = "hidden";
  }
});
// Motto Module
const documentMotto = doc(collectionSettings, "motto");
onSnapshot(documentMotto, (doc) => {
  if (doc.exists()) {
    if (doc.data().boolean === true) {
      mottoText.style.visibility = "visible";
    } else {
      mottoText.style.visibility = "hidden";
    }
    mottoUpdate(language);
  } else {
    mottoText.style.visibility = "hidden";
  }
});
// Reminder Module
const eventModule = document.querySelector(".module-event");
const documentReminder = doc(collectionSettings, "reminder");
onSnapshot(documentReminder, (doc) => {
  if (doc.exists()) {
    if (doc.data().boolean === true) {
      eventModule.style.visibility = "visible";
    } else {
      eventModule.style.visibility = "hidden";
    }
    reminderUpdate(language);
  } else {
    eventModule.style.visibility = "hidden";
  }
});
const wetterModule = document.querySelector(".module-weather");
const documentWeather = doc(collectionSettings, "weather");
onSnapshot(documentWeather, (doc) => {
  if (doc.exists()) {
    if (doc.data().boolean === true) {
      wetterModule.style.visibility = "visible";
    } else {
      wetterModule.style.visibility = "hidden";
    }
    reminderUpdate(language);
  } else {
    wetterModule.style.visibility = "hidden";
  }
});

// -------------------------------- //
// Zeit und Datum

const dateText = document.querySelector("#date-text");
const timeText = document.querySelector("#time-text");
const secText = document.querySelector("#sec-text");
const monthList = {
  en: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ],
  de: [
    "Januar",
    "Februar",
    "März",
    "April",
    "Mai",
    "Juni",
    "Juli",
    "August",
    "September",
    "Oktober",
    "November",
    "Dezember",
  ],
  fr: [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
  ],
};
const dayList = {
  en: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ],
  de: [
    "Sonntag",
    "Montag",
    "Dienstag",
    "Mittwoch",
    "Donnerstag",
    "Freitag",
    "Samstag",
  ],
  fr: ["dimache", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"],
};

function nullFix(int) {
  return int < 10 ? "0" + int : int;
}

function timeUpdate(language) {
  const date = new Date();
  const monthNames = monthList[language];
  const dayNames = dayList[language];
  dateText.textContent = `${dayNames[date.getDay()]} - ${date.getDate()} ${
    monthNames[date.getMonth()]
  } ${date.getFullYear()}`;
  timeText.textContent = `${date.getHours()}:${nullFix(date.getMinutes())}`;
  secText.textContent = `${nullFix(date.getSeconds())}`;
}

setInterval(() => {
  timeUpdate(language);
}, 1000);

// -------------------------------- //
// Mottotexte

const mottoText = document.querySelector("#motto-text");
const mottoNormal = {
  en: [
    "Hello!",
    "Good day",
    "Carry on!",
    "You're doing great today!",
    "Hiii",
    "Final Project 2023",
    "You look stunning",
    "How are you?",
    "I missed u <3",
    "It was so boring without you",
    "I hope you have fun today!",
    "Have you eaten yet?",
    "What are you doing today?",
  ],
  de: [
    "Hallo!",
    "Guten Tag",
    "Mach weiter so!",
    "Heute machst du's super!",
    "Hey",
    "Abschlussprojekt 2023",
    "Du siehst umwerfend aus",
    "Wie gehts dir?",
    "Ich hab dich vermisst <3",
    "Es war so langweilig ohne dich",
    "Ich hoffe du hast Spass heute!",
    "Hast du schon gegessen?",
    "Was machst du heute?",
  ],
  fr: [
    "Salut!",
    "Bonne Journée",
    "Continue comme ça!",
    "Tu travailles bien aujourd'hui",
    "Salut",
    "Projet de fin d'études 2023",
    "Tu es magnifique",
    "Comment ça va?",
    "Tu m'as manqué <3",
    "C'était tellement ennuyeux sans toi",
    "J'espère que tu t'amuses aujourd'hui!",
    "As-tu déjà mangé?",
    "Qu'est-ce que tu fais aujourd'hui?",
  ],
};
const mottoMorning = {
  en: [
    "Good morning",
    "Time to wake up",
    "Look who's awake!",
    "You look good!",
    "We wish you a nice day",
  ],
  de: [
    "Guten Morgen",
    "Zeit zum aufwachen",
    "Schau mal, wer wach ist!",
    "Du siehst gut aus!",
    "Wir wünschen dir einen schönen Tag",
  ],
  fr: [
    "Bonjour",
    "Il est temps de se réveiller",
    "Regarde qui est réveillé !",
    "Tu as l'air bien !",
    "Nous te souhaitons une belle journée",
  ],
};
const mottoEvening = {
  en: [
    "Good evening",
    "How was your day?",
    "Time to relax",
    "Another day nearly accomplished",
  ],
  de: [
    "Guten Abend",
    "Wie war dein Tag?",
    "Zeit zum entspannen",
    "Ein weiteren Tag fast geschafft",
  ],
  fr: [
    "Bonsior",
    "Comment s'est passé ta journée ?",
    "Temps de se détendre",
    "Presque encore une journée de faite",
  ],
};
const mottoNight = {
  en: ["Good Night", "Sleep well", "You did well today", "Zzz..."],
  de: ["Gute Nacht", "Schlaf gut", "Du warst gut heute", "Zzz..."],
  fr: ["Bonne nuit", "Dors bien", "Tu as bien fait", "Zzz..."],
};
const mottoArray = [];
function mottoUpdate(language) {
  mottoArray.length = "0";
  const date = new Date();
  if (date.getHours() >= 5 && date.getHours() <= 18) {
    mottoArray.push(...mottoNormal[language]);
  }
  if (date.getHours() >= 4 && date.getHours() <= 11) {
    mottoArray.push(...mottoMorning[language]);
  }
  if (date.getHours() >= 17 && date.getHours() <= 20) {
    mottoArray.push(...mottoEvening[language]);
  }
  if (date.getHours() >= 21 && date.getHours() <= 24) {
    mottoArray.push(...mottoNight[language]);
  }
  const randomIndex = Math.floor(Math.random() * mottoArray.length);
  mottoText.textContent = `${mottoArray[randomIndex]}`;
}

setInterval(() => {
  mottoUpdate(language);
}, 300000);

// -------------------------------- //
// Reminders


function eventLanguage(language) {
  const eventModuleText = document.getElementById("event-text");

  if (language === "en") {
    eventModuleText.textContent = "Upcoming Events";
  } else if (language === "de") {
    eventModuleText.textContent = "Bevorstehende Events";
  } else if (language === "fr") {
    eventModuleText.textContent = "Événements à venir";
  } else {
    eventModuleText.textContent = "Upcoming Events";
  }
}
function ifToday(dateString, language) {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var today = `${day < 10 ? "0" + day : day}.${
    month < 10 ? "0" + month : month
  }`;

  if (today === dateString) {
    if (language === "en") {
      return "Today";
    } else if (language === "de") {
      return "Heute";
    } else {
      return "Aujourd'hui";
    }
  } else {
    return dateString;
  }
}
function checkTime(time) {
  if (time === "23:45") {
    return "--:--";
  } else {
    return time;
  }
}
function reminderUpdate(language) {
  const collectionReminder = collection(db, "reminder");
  const q = query(collectionReminder, where("check", "==", "a"));
  getDocs(q)
    .then((snapshot) => {
      const date = new Date();
      const currentDate = date.setMinutes(date.getMinutes() - 15);

      const sortedDocs = snapshot.docs
        .filter((doc) => {
          const date = doc.data().date;
          const time = doc.data().time;
          const dateTime = time ? new Date(`${date} ${time}`) : new Date(date);
          return dateTime >= currentDate;
        })
        .sort((doc1, doc2) => {
          const date1 = doc1.data().date;
          const time1 = doc1.data().time;
          const date2 = doc2.data().date;
          const time2 = doc2.data().time;

          if (!time1 && !time2) {
            return new Date(date1) - new Date(date2);
          }

          if (!time1) {
            return 1;
          }

          if (!time2) {
            return -1;
          }

          const dateTime1 = new Date(`${date1} ${time1}`);
          const dateTime2 = new Date(`${date2} ${time2}`);
          return dateTime1 - dateTime2;
        });

      const timeArray = [];
      const dateArray = [];
      const textArray = [];

      sortedDocs.forEach((doc) => {
        const { time, date, text } = doc.data();

        const dateParts = date.split("-");
        const day = dateParts[2];
        const month = dateParts[1];
        const formattedDate = `${day}.${month}`;

        timeArray.push(time);
        dateArray.push(formattedDate);
        textArray.push(text);
      });

      const events = document.querySelectorAll(".events");
      for (i = 0; i < 5; i++) {
        events[i].textContent = `${ifToday(dateArray[i], language)} ${
          checkTime(timeArray[i])} | ${textArray[i]}`;
      }
      for (let i = dateArray.length; i < 5; i++) {
        events[i].textContent = "-";
      }
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}

setInterval(() => {
  reminderUpdate(language);
  const date = new Date()
  weatherUpdate(date);
}, 60000);

const collectionReminder = collection(db, "reminder");
onSnapshot(collectionReminder, (querySnapshot) => {
  querySnapshot.forEach((doc) => {
    if (doc.exists()) {
      reminderUpdate(language);
    }
  });
});

/* ----------------- */
// Reminder all Years



const documentYear = doc(collectionSettings, "yearsReminder");
onSnapshot(documentMotto, (doc) => {
  const date = new Date();
  if (doc.exists()) {
    if (doc.data().year != date.getFullYear()) {
      yearlierReminderUpdate()
      updateDoc(documentYear, { year: date.getFullYear() });
    }
  }
});
function yearlierReminderUpdate() {
  const collectionYearlier = collection(db, "yearlier");
  const q = query(collectionYearlier, where("check", "==", "a"));
  
  getDocs(q)
    .then((snapshot) => {
      const textArray = [];
      const dateArray = [];
      const titleArray = [];
      snapshot.docs.forEach((doc) => {
        const randomTitle = Math.random().toString(36).substring(7);
        const data = doc.data();
        const text = data.text;
        const date = data.date;
        
        textArray.push(text)
        dateArray.push(date)
        titleArray.push(randomTitle)
      })
      for (i = 0; i < textArray.length; i++) {
        const date = new Date()
        setDoc(doc(db, "reminder", titleArray[i]), {
          text: textArray[i],
          date: `${date.getFullYear()}-${dateArray[i]}`,
          time: "23:45",
          check: "a",
        });
      }
    })
}





// -------------------------------- //
// News

function newsUpdate() {
  const collectionNews = collection(db, `news-${language}`);
  const date = new Date();
  const time = `${date.getHours()}:00 - ${date.getDate()}.${date.getMonth()}.${date.getFullYear()}`;
  const q = query(collectionNews, where("time", "==", time));

  getDocs(q).then((querySnapshot) => {
    if (querySnapshot.size >= 1) {
      newsGet();
    } else {
      newsUpdateDoc();
    }
  });
}
function newsUpdateDoc() {
  const apiKey = "5c38cd27597c4b0db417109814070b7c";
  const apiUrl = `https://newsapi.org/v2/top-headlines?language=${language}&apiKey=${apiKey}`;
  fetch(apiUrl)
    .then((response) => response.json())
    .then((data) => {
      data.articles.forEach((article) => {
        const publishedTime = article.publishedAt;
        const dateObj = new Date(publishedTime);
        const day = dateObj.getDate();
        const month = dateObj.getMonth() + 1;
        const hours = dateObj.getHours();
        const minutes = dateObj.getMinutes();
        const formattedTime = `${day < 10 ? "0" + day : day}.${
          month < 10 ? "0" + month : month
        }. - ${hours}:${nullFix(minutes)}`;
        const authorPart = ` - ${article.author}`;
        const modifiedTitle = article.title.replace(authorPart, "");

        const date = new Date();
        const time = `${date.getHours()}:00 - ${date.getDate()}.${date.getMonth()}.${date.getFullYear()}`;

        const randomTitle = Math.random().toString(36).substring(7);
        setDoc(doc(db, `news-${language}`, randomTitle), {
          news: modifiedTitle,
          author: article.author,
          release: formattedTime,
          time: time,
        });
      });
      newsGet();
    });
}
const authorArray = [];
const releaseArray = [];
const titleArray = [];
function newsGet() {
  const collectionNews = collection(db, `news-${language}`);
  const date = new Date();
  const time = `${date.getHours()}:00 - ${date.getDate()}.${date.getMonth()}.${date.getFullYear()}`;
  const q = query(collectionNews, where("time", "==", time));
  authorArray.length = 0;
  releaseArray.length = 0;
  titleArray.length = 0;

  getDocs(q).then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
      const { author, release, news } = doc.data();
      authorArray.push(author);
      releaseArray.push(release);
      titleArray.push(news);
    });
    newsModule();
  });
}
const newsText = document.querySelector("#news-text");
const newsTimeText = document.querySelector("#newsTime-text");
function newsModule() {
  const randomIndex = Math.floor(Math.random() * titleArray.length);
  newsText.textContent = `${titleArray[randomIndex]}`;
  newsTimeText.textContent = `${authorArray[randomIndex]} | ${releaseArray[randomIndex]}`;
}

setInterval(() => {
  newsUpdate();
}, 300000);

/* ----------------- */
// Weather

const city = "Solothurn";
const collectionWeather = collection(db, `weather-${city}`);
function weatherUpdate(date) {
  const time = `${date.getFullYear()}-${nullFix(date.getMonth() + 1)}-${nullFix(date.getDate())} ${nullFix(date.getHours())}:00`;
  const q = query(collectionWeather, where("time", "==", time));

  getDocs(q).then((querySnapshot) => {
    if (querySnapshot.size >= 1) {
      weatherGet();
    } else {
      weatherUpdateDoc();
    }
  });
}
function weatherUpdateDoc() {
  const weatherAPi = `https://api.weatherapi.com/v1/forecast.json?key=8667fc27f08e465696c111527230605&q=${city}&days=1&aqi=no&alerts=no`;
  fetch(weatherAPi)
    .then((response) => response.json())
    .then((data) => {
        const forecastHourReport = data.forecast.forecastday[0].hour;
        forecastHourReport.forEach((data) => {
          const randomTitle = Math.random().toString(36).substring(7);
          setDoc(doc(db, `weather-${city}`, randomTitle), {
            condition: data.condition.text,
            temp_c: data.temp_c,
            feel_c: data.feelslike_c,
            icon: data.condition.icon,
            time: data.time,
          });
        });
        weatherGet();
  });
}
function weatherUpdateDocNext(date) {
    const weatherApi = `https://api.weatherapi.com/v1/forecast.json?key=8667fc27f08e465696c111527230605&q=${city}&days=2&aqi=no&alerts=no`;
    fetch(weatherApi)
      .then((response) => response.json())
      .then((data) => {
        const forecastHourReport = data.forecast.forecastday[1].hour;
        forecastHourReport.forEach((data) => {
          const randomTitle = Math.random().toString(36).substring(7);
          setDoc(doc(db, `weather-${city}`, randomTitle), {
            condition: data.condition.text,
            temp_c: data.temp_c,
            feel_c: data.feelslike_c,
            icon: data.condition.icon,
            time: data.time,
          });
        });
        getDataWeather(date)
      });
}


const tempCArray = [];
const feelCArray = [];
const conditionArray = [];
const iconArray = [];
function getDataWeather(date) {
  tempCArray.length = 0;
  feelCArray.length = 0;
  conditionArray.length = 0;
  iconArray.length = 0;
  const time = `${date.getFullYear()}-${nullFix(date.getMonth() + 1)}-${nullFix(date.getDate())} ${nullFix(date.getHours())}:00`;
      const q = query(collectionWeather, where("time", "==", time));
      getDocs(q).then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          const { condition, temp_c, feel_c, icon } = doc.data();
          tempCArray.push(temp_c);
          feelCArray.push(feel_c);
          conditionArray.push(condition);
          iconArray.push(icon)
        });
        weatherModule()
    });
}

function weatherGet() {
  const collectionWeather = collection(db, `weather-${city}`);
  for (let i = 0; i < 3; i++) {
    const date = new Date();
    date.setHours(date.getHours() + i);
    if (date.getHours() <= 2) {
      const time = `${date.getFullYear()}-${nullFix(date.getMonth() + 1)}-${nullFix(date.getDate())} ${nullFix(date.getHours())}:00`;
      const q = query(collectionWeather, where("time", "==", time));

      getDocs(q).then((querySnapshot) => {
        if (querySnapshot.size >= 1) {
          getDataWeather(date)
        } else {
          weatherUpdateDocNext(date)
        }
      });
    }
    if (date.getHours() >= 3) {
      getDataWeather(date)
    }
  }
}
const weathers = document.querySelectorAll(".weathers");
const times = document.querySelectorAll(".times");
const icons = document.querySelectorAll(".icons");
function weatherModule() {
  for (let i = 0; i < 3; i++) {
    const date = new Date();
    date.setHours(date.getHours() + i)
    weathers[i].textContent = `~${tempCArray[i]}°C`;
    times[i].textContent = `${date.getHours()}:00`;
    icons[i].src = `${iconArray[i]}`
  }
}


